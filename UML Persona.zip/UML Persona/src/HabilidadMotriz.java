public interface HabilidadMotriz {

	public void mover();

}
