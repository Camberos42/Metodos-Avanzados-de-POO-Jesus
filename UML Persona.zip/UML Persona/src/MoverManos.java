
public class MoverManos implements HabilidadMotriz {
	
	public void mover() {
		System.out.println("Moviendo manitas");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
