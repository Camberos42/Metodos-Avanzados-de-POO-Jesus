
public class KnifeBehavior implements WeaponBehavior {
	
	public String useWeapon(){
		return ("Yo utilizo cuchillos para atacar");
		}

}
