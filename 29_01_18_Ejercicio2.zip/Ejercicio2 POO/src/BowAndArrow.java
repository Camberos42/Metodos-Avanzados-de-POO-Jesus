
public class BowAndArrow implements WeaponBehavior{
	
	public String useWeapon(){
		return ("Yo utilizo arco y flecha para atacar");
	}
}
