
public class SwordBehavior implements WeaponBehavior{

	public String useWeapon() {
		return "Yo utilizo espadas para atacar";
		
	}

}
