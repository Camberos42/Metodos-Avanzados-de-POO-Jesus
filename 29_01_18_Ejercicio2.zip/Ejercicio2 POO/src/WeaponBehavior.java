public interface WeaponBehavior {
	String useWeapon();

}
