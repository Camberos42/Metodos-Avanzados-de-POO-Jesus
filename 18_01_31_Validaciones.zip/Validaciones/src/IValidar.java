
public interface IValidar {

}
