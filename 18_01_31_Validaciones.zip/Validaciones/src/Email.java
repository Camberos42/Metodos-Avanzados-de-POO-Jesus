
public class Email extends Formulario{
	
	public Email(){
		setValidacion(new Validar_Email());
	}
	
	@Override
	public void validar(String s){
		if(getValidacion().comprobar(s)){
			System.out.println("Campo validado");
		}
		else{
			System.out.println("Campo no validado");
		}
	}

}
