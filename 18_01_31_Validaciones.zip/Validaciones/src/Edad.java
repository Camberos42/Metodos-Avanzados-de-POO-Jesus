
public class Edad extends Formulario{

		public void validar(String str){
			if(getValidacion().comprobacion(str)){
				System.out.println("Validado");
			}
			else{
				System.out.println("No Validado");
			}
		}
		
		public Edad(){
			setValidar(new Validar_Num());}
		
}
