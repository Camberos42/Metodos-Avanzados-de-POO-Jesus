
public class Id extends Formulario{

		public void validar(String str){
			if(getValidacion().comprobar(str)){
				System.out.println("Validado");
			}
			else{
				System.out.println("No Validado");
			}
		}
		
		public Id(){
			setValidar(new Validar_Num());}
		

}
